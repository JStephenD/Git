<html>
<head>
<title>PHP Object-Oriented Programming + MVC</title>
<link href="web/css/style.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <h2>PHP Object-Oriented Programming + MVC</h2>
    <div>
        <ul class="menu-list">
            <li><a href="index.php">Student</a></li>
            <li><a href="index.php?action=attendance">Attendance</a></li>
        </ul>
    </div>