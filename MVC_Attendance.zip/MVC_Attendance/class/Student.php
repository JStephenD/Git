<?php

require_once('class/DBController.php');

class Student{
    private $db_handle;

    function __construct(){
        $this->db_handle = new DBController();
    }

    function addStudent($name, $roll_number,$dob, $class){
        $query = "INSERT INTO tbl_student (name,roll_number,dob,class) VALUES (?,?,?,?)";
        $param_type = 'siss';
        $param_value = array(
            $name,
            $roll_number,
            $dob,
            $class
        );

        $insertId = $this->db_handle->insert($query, $param_type, $param_value);
    }

    function editStudent($name,$roll_number,$dob,$class,$student_id){
        $query = "UPDATE tbl_student SET name=?,roll_number=?,dob=?,class=? WHERE id=?";
        $param_type = 'sissi';
        $param_value = array(
            $name,
            $roll_number,
            $dob,
            $class,
            $student_id
        );

        $this->db_handle->update($query, $param_type, $param_value);
    }

    function deleteStudent($student_id){
        $query = "DELETE FROM tbl_student WHERE id=?";
        $param_type = 'i';
        $param_value = array(
            $student_id
        );

        $this->db_handle->update($query, $param_type, $param_value);
    }

    function getStudentById($student_id){
        $query = "SELECT * FROM tbl_student WHERE id=?";
        $param_type = 'i';
        $param_value = array(
            $student_id
        );

        $result = $this->db_handle->runQuery($query, $param_type, $param_value);
        return $result;
    }

    function getAllStudent(){
        $sql = "SELECT * FROM tbl_student ORDER BY id";
        $result = $this->db_handle->runBaseQuery($sql);
        return $result;
    }
}

?>